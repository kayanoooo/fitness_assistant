package com.example.fitness_assist

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class LoginFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_login, container, false)

        val emailEditText = view.findViewById<EditText>(R.id.et_email)
        val passwordEditText = view.findViewById<EditText>(R.id.et_password)
        val loginButton = view.findViewById<Button>(R.id.btn_login)
        val registerButton = view.findViewById<Button>(R.id.btn_register)
        val skipTextView = view.findViewById<TextView>(R.id.tv_skip)

        if (isUserLoggedIn()) {
            navigateToHome()
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (validateInput(email, password)) {
                if (loginUser(email, password)) {
                    Toast.makeText(context, "Вход успешен!", Toast.LENGTH_SHORT).show()
                    navigateToHome()
                } else {
                    Toast.makeText(context, "Неверный email или пароль", Toast.LENGTH_SHORT).show()
                }
            }
        }

        registerButton.setOnClickListener {
            val email = emailEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()

            if (validateInput(email, password)) {
                if (registerUser(email, password)) {
                    Toast.makeText(context, "Регистрация успешна!", Toast.LENGTH_SHORT).show()
                    navigateToHome()
                } else {
                    Toast.makeText(context, "Пользователь уже существует", Toast.LENGTH_SHORT).show()
                }
            }
        }

        skipTextView.setOnClickListener {
            saveGuestUser()
            Toast.makeText(context, "Вход как гость", Toast.LENGTH_SHORT).show()
            navigateToHome()
        }

        return view
    }

    private fun validateInput(email: String, password: String): Boolean {
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(context, "Заполните все поля", Toast.LENGTH_SHORT).show()
            return false
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(context, "Введите корректный email", Toast.LENGTH_SHORT).show()
            return false
        }

        if (password.length < 6) {
            Toast.makeText(context, "Пароль должен быть не менее 6 символов", Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    private fun loginUser(email: String, password: String): Boolean {
        return UserPrefsUtils.checkUserCredentials(requireContext(), email, password).also { success ->
            if (success) {
                UserPrefsUtils.setCurrentUser(requireContext(), email, false)
            }
        }
    }

    private fun registerUser(email: String, password: String): Boolean {
        if (UserPrefsUtils.userExists(requireContext(), email)) {
            return false
        }

        UserPrefsUtils.saveUserCredentials(requireContext(), email, password)
        UserPrefsUtils.setCurrentUser(requireContext(), email, false)
        return true
    }

    private fun isUserLoggedIn(): Boolean {
        val prefs = UserPrefsUtils.getSharedPreferences(requireContext())
        val isGuest = prefs.getBoolean("current_user_is_guest", false)
        val userEmail = prefs.getString("current_user_email", null)

        return isGuest || userEmail != null
    }

    private fun saveGuestUser() {
        UserPrefsUtils.setCurrentUser(requireContext(), null, true)
    }

    private fun navigateToHome() {
        findNavController().navigate(R.id.action_login_to_home)
    }
}