package com.example.fitness_assist

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*

class UserProfileFragment : Fragment() {

    private lateinit var userProfile: UserProfile
    private var profileImageUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            profileImageUri = data?.data
            saveProfileImage()
            updateProfileImage()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_user_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadUserProfile()

        val profileImage = view.findViewById<ImageView>(R.id.image_profile)
        val nameEditText = view.findViewById<EditText>(R.id.edit_name)
        val ageEditText = view.findViewById<EditText>(R.id.edit_age)
        val heightEditText = view.findViewById<EditText>(R.id.edit_height)
        val weightEditText = view.findViewById<EditText>(R.id.edit_weight)
        val genderSpinner = view.findViewById<Spinner>(R.id.spinner_gender)
        val goalSpinner = view.findViewById<Spinner>(R.id.spinner_goal)
        val activitySpinner = view.findViewById<Spinner>(R.id.spinner_activity)
        val saveButton = view.findViewById<Button>(R.id.button_save_profile)
        val changeImageButton = view.findViewById<Button>(R.id.button_change_image)
        val statsTextView = view.findViewById<TextView>(R.id.text_stats)

        nameEditText.setText(userProfile.name)
        ageEditText.setText(userProfile.age?.toString() ?: "")
        heightEditText.setText(userProfile.height?.toString() ?: "")
        weightEditText.setText(userProfile.weight?.toString() ?: "")

        setupGenderSpinner(genderSpinner)
        setupGoalSpinner(goalSpinner)
        setupActivitySpinner(activitySpinner)

        if (userProfile.profileImageUri.isNotEmpty()) {
            profileImageUri = Uri.parse(userProfile.profileImageUri)
            updateProfileImage()
        }

        changeImageButton.setOnClickListener {
            pickProfileImage()
        }

        saveButton.setOnClickListener {
            saveUserProfile(
                nameEditText.text.toString(),
                ageEditText.text.toString(),
                heightEditText.text.toString(),
                weightEditText.text.toString(),
                genderSpinner.selectedItemPosition,
                goalSpinner.selectedItemPosition,
                activitySpinner.selectedItemPosition
            )
            updateStats(statsTextView)
            Toast.makeText(requireContext(), "Профиль сохранен", Toast.LENGTH_SHORT).show()
        }

        updateStats(statsTextView)
    }

    override fun onResume() {
        super.onResume()
        val statsTextView = view?.findViewById<TextView>(R.id.text_stats)
        if (statsTextView != null) {
            updateStats(statsTextView)
        }
    }

    private fun setupGenderSpinner(spinner: Spinner) {
        val genders = arrayOf("Не указан", "Мужской", "Женский")
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, genders)
        spinner.adapter = adapter

        when (userProfile.gender) {
            "male" -> spinner.setSelection(1)
            "female" -> spinner.setSelection(2)
            else -> spinner.setSelection(0)
        }
    }

    private fun setupGoalSpinner(spinner: Spinner) {
        val goals = arrayOf(
            "Похудение",
            "Набор массы",
            "Поддержание формы",
            "Увеличение силы",
            "Выносливость"
        )
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, goals)
        spinner.adapter = adapter

        val goalMap = mapOf(
            "weight_loss" to 0,
            "muscle_gain" to 1,
            "maintenance" to 2,
            "strength" to 3,
            "endurance" to 4
        )
        spinner.setSelection(goalMap[userProfile.fitnessGoal] ?: 2)
    }

    private fun setupActivitySpinner(spinner: Spinner) {
        val activities = arrayOf(
            "Сидячий образ жизни",
            "Легкая активность",
            "Умеренная активность",
            "Высокая активность",
            "Очень высокая активность"
        )
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, activities)
        spinner.adapter = adapter

        val activityMap = mapOf(
            "sedentary" to 0,
            "light" to 1,
            "moderate" to 2,
            "active" to 3,
            "very_active" to 4
        )
        spinner.setSelection(activityMap[userProfile.activityLevel] ?: 2)
    }

    private fun loadUserProfile() {
        val json = UserPrefsUtils.getString(requireContext(), "user_profile", "{}")
        userProfile = Gson().fromJson(json, UserProfile::class.java) ?: UserProfile()
    }

    private fun saveUserProfile(
        name: String,
        ageText: String,
        heightText: String,
        weightText: String,
        genderIndex: Int,
        goalIndex: Int,
        activityIndex: Int
    ) {
        userProfile.name = name
        userProfile.age = ageText.toIntOrNull()
        userProfile.height = heightText.toDoubleOrNull()
        userProfile.weight = weightText.toDoubleOrNull()
        userProfile.gender = when (genderIndex) {
            1 -> "male"
            2 -> "female"
            else -> "unknown"
        }
        userProfile.fitnessGoal = when (goalIndex) {
            0 -> "weight_loss"
            1 -> "muscle_gain"
            2 -> "maintenance"
            3 -> "strength"
            4 -> "endurance"
            else -> "maintenance"
        }
        userProfile.activityLevel = when (activityIndex) {
            0 -> "sedentary"
            1 -> "light"
            2 -> "moderate"
            3 -> "active"
            4 -> "very_active"
            else -> "moderate"
        }
        userProfile.lastUpdated = System.currentTimeMillis()

        userProfile.dailyCalorieGoal = userProfile.calculateDailyCalories() ?: 2000

        val json = Gson().toJson(userProfile)
        UserPrefsUtils.putString(requireContext(), "user_profile", json)

        UserPrefsUtils.putInt(requireContext(), "calorie_goal", userProfile.dailyCalorieGoal)
    }

    private fun updateStats(statsTextView: TextView) {
        val stats = StringBuilder()

        // ИМТ
        val bmi = userProfile.calculateBMI()
        if (bmi != null) {
            stats.append("ИМТ: ${String.format("%.1f", bmi)}\n")
            stats.append("Категория: ${userProfile.getBMICategory()}\n\n")
        }

        val recommendedCalories = userProfile.calculateDailyCalories()
        if (recommendedCalories != null) {
            stats.append("Рекомендуемые калории:\n")
            stats.append("$recommendedCalories ккал/день\n\n")
        }

        val workoutStats = getWorkoutStatistics()
        stats.append(workoutStats)

        statsTextView.text = stats.toString()
    }

    private fun getWorkoutStatistics(): String {
        try {
            val historyJson = UserPrefsUtils.getString(requireContext(), "workout_history", "[]")
            val gson = Gson()
            val type = object : TypeToken<List<WorkoutHistory>>() {}.type
            val historyList = gson.fromJson<List<WorkoutHistory>>(historyJson, type) ?: emptyList()

            if (historyList.isEmpty()) {
                return "📊 Статистика тренировок:\n   Нет данных"
            }

            val totalWorkouts = historyList.size
            val totalDuration = historyList.sumOf { it.duration }
            val avgDuration = if (totalWorkouts > 0) totalDuration / totalWorkouts else 0
            val totalCalories = historyList.sumOf { it.caloriesBurned ?: 0 }

            val lastWorkout = historyList.firstOrNull()
            val lastWorkoutDate = if (lastWorkout != null) {
                val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
                dateFormat.format(Date(lastWorkout.date))
            } else {
                "нет"
            }

            return """
            📊 Статистика тренировок:
            • Всего тренировок: $totalWorkouts
            • Общее время: ${totalDuration} мин
            • Средняя длительность: ${avgDuration} мин
            • Сожжено калорий: ${totalCalories} ккал
            • Последняя тренировка: $lastWorkoutDate
        """.trimIndent()
        } catch (e: Exception) {
            e.printStackTrace()
            return "📊 Статистика тренировок:\n   Ошибка загрузки"
        }
    }

    private fun pickProfileImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        pickImageLauncher.launch(intent)
    }

    private fun saveProfileImage() {
        profileImageUri?.let { uri ->
            userProfile.profileImageUri = uri.toString()
            val json = Gson().toJson(userProfile)
            UserPrefsUtils.putString(requireContext(), "user_profile", json)
        }
    }

    private fun updateProfileImage() {
        profileImageUri?.let { uri ->
            view?.findViewById<ImageView>(R.id.image_profile)?.let { imageView ->
                Glide.with(this)
                    .load(uri)
                    .circleCrop()
                    .into(imageView)
            }
        }
    }
}