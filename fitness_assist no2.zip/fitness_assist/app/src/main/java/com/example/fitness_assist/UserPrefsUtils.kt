package com.example.fitness_assist

import android.content.Context
import android.content.SharedPreferences

object UserPrefsUtils {

    private const val PREFS_NAME = "com.example.fitness_assist_prefs"

    fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    private fun getKeyWithUser(context: Context, key: String): String {
        val prefs = getPrefs(context)
        val userEmail = prefs.getString("current_user_email", "") ?: ""
        val isGuest = prefs.getBoolean("current_user_is_guest", true)

        return if (isGuest || userEmail.isEmpty()) {
            "guest_$key"
        } else {
            "user_${userEmail.hashCode()}_$key"
        }
    }

    fun getInt(context: Context, key: String, defaultValue: Int): Int {
        val userKey = getKeyWithUser(context, key)
        return getPrefs(context).getInt(userKey, defaultValue)
    }

    fun putInt(context: Context, key: String, value: Int) {
        val userKey = getKeyWithUser(context, key)
        getPrefs(context).edit().putInt(userKey, value).apply()
    }

    fun getString(context: Context, key: String, defaultValue: String): String {
        val userKey = getKeyWithUser(context, key)
        return getPrefs(context).getString(userKey, defaultValue) ?: defaultValue
    }

    fun putString(context: Context, key: String, value: String) {
        val userKey = getKeyWithUser(context, key)
        getPrefs(context).edit().putString(userKey, value).apply()
    }

    fun remove(context: Context, key: String) {
        val userKey = getKeyWithUser(context, key)
        getPrefs(context).edit().remove(userKey).apply()
    }

    fun getBoolean(context: Context, key: String, defaultValue: Boolean): Boolean {
        val userKey = getKeyWithUser(context, key)
        return getPrefs(context).getBoolean(userKey, defaultValue)
    }

    fun putBoolean(context: Context, key: String, value: Boolean) {
        val userKey = getKeyWithUser(context, key)
        getPrefs(context).edit().putBoolean(userKey, value).apply()
    }

    fun setCurrentUser(context: Context, email: String? = null, isGuest: Boolean = true) {
        val prefs = getPrefs(context)
        prefs.edit()
            .putString("current_user_email", email)
            .putBoolean("current_user_is_guest", isGuest)
            .apply()
    }

    fun getCurrentUserEmail(context: Context): String {
        return getPrefs(context).getString("current_user_email", "Гость") ?: "Гость"
    }

    fun isGuest(context: Context): Boolean {
        return getPrefs(context).getBoolean("current_user_is_guest", true)
    }

    fun logout(context: Context) {
        val prefs = getPrefs(context)
        prefs.edit()
            .remove("current_user_email")
            .remove("current_user_is_guest")
            .apply()
    }

    fun saveUserCredentials(context: Context, email: String, password: String) {
        val prefs = getPrefs(context)
        val userKey = "user_cred_${email.hashCode()}"
        prefs.edit()
            .putString(userKey, password)
            .apply()
    }

    fun checkUserCredentials(context: Context, email: String, password: String): Boolean {
        val prefs = getPrefs(context)
        val userKey = "user_cred_${email.hashCode()}"
        val savedPassword = prefs.getString(userKey, null)
        return savedPassword == password
    }

    fun userExists(context: Context, email: String): Boolean {
        val prefs = getPrefs(context)
        val userKey = "user_cred_${email.hashCode()}"
        return prefs.contains(userKey)
    }

    fun resetCurrentUserData(context: Context) {
        val prefs = getPrefs(context)
        val userEmail = getCurrentUserEmail(context)
        val isGuest = isGuest(context)

        val prefix = if (isGuest || userEmail == "Гость") {
            "guest_"
        } else {
            "user_${userEmail.hashCode()}_"
        }

        val allKeys = prefs.all.keys
        val keysToRemove = allKeys.filter { it.startsWith(prefix) }

        val editor = prefs.edit()
        keysToRemove.forEach { key ->
            editor.remove(key)
        }
        editor.apply()
    }

    fun getSharedPreferences(context: Context): SharedPreferences {
        return getPrefs(context)
    }
}