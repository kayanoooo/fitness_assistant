package com.example.fitness_assist

import android.os.Bundle
import android.os.CountDownTimer
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.*

class WorkoutExecutionFragment : Fragment() {

    private lateinit var currentWorkout: CustomWorkout
    private var currentExerciseIndex = 0
    private var currentSetIndex = 0
    private var workoutStartTime: Long = 0
    private var timerRunning = false
    private var elapsedTime = 0L
    private var timerJob: Job? = null
    private var restTimer: CountDownTimer? = null

    companion object {
        private const val ARG_WORKOUT = "workout"

        fun newInstance(workout: CustomWorkout): WorkoutExecutionFragment {
            val fragment = WorkoutExecutionFragment()
            val args = Bundle()
            args.putString(ARG_WORKOUT, Gson().toJson(workout))
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_workout_execution, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        try {
            val workoutJson = arguments?.getString(ARG_WORKOUT)
            if (workoutJson == null) {
                Toast.makeText(requireContext(), "Ошибка загрузки тренировки", Toast.LENGTH_SHORT).show()
                requireActivity().supportFragmentManager.popBackStack()
                return
            }

            currentWorkout = Gson().fromJson(workoutJson, CustomWorkout::class.java)
            workoutStartTime = System.currentTimeMillis()
            startTimer()
            setupUI(view)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка запуска тренировки", Toast.LENGTH_SHORT).show()
            requireActivity().supportFragmentManager.popBackStack()
        }
    }

    private fun setupUI(view: View) {
        val exerciseName = view.findViewById<TextView>(R.id.text_exercise_name)
        val exerciseDesc = view.findViewById<TextView>(R.id.text_exercise_desc)
        val currentSet = view.findViewById<TextView>(R.id.text_current_set)
        val totalSets = view.findViewById<TextView>(R.id.text_total_sets)
        val reps = view.findViewById<TextView>(R.id.text_reps)
        val weight = view.findViewById<TextView>(R.id.text_weight)
        val timerText = view.findViewById<TextView>(R.id.text_timer)
        val restTimerView = view.findViewById<TextView>(R.id.text_rest_timer)
        val btnCompleteSet = view.findViewById<Button>(R.id.button_complete_set)
        val btnSkipRest = view.findViewById<Button>(R.id.button_skip_rest)
        val btnFinishWorkout = view.findViewById<Button>(R.id.button_finish_workout)

        updateCurrentExerciseUI(
            exerciseName, exerciseDesc, currentSet, totalSets,
            reps, weight, timerText
        )

        btnCompleteSet.setOnClickListener {
            completeCurrentSet()
            if (currentSetIndex < currentWorkout.exercises[currentExerciseIndex].sets - 1) {
                startRestTimer(restTimerView, btnSkipRest)
                currentSetIndex++
                updateCurrentSetUI(currentSet, totalSets)
            } else {
                currentExerciseIndex++
                currentSetIndex = 0
                if (currentExerciseIndex < currentWorkout.exercises.size) {
                    updateCurrentExerciseUI(
                        exerciseName, exerciseDesc, currentSet, totalSets,
                        reps, weight, timerText
                    )
                } else {
                    finishWorkout()
                }
            }
        }

        btnSkipRest.setOnClickListener {
            restTimer?.cancel()
            restTimerView.visibility = View.GONE
            btnSkipRest.visibility = View.GONE
        }

        btnFinishWorkout.setOnClickListener {
            finishWorkout()
        }
    }

    private fun updateCurrentExerciseUI(
        exerciseName: TextView,
        exerciseDesc: TextView,
        currentSet: TextView,
        totalSets: TextView,
        reps: TextView,
        weight: TextView,
        timerText: TextView
    ) {
        val currentExercise = currentWorkout.exercises[currentExerciseIndex]

        exerciseName.text = currentExercise.name
        exerciseDesc.text = currentExercise.description
        currentSet.text = "Подход ${currentSetIndex + 1}"
        totalSets.text = "из ${currentExercise.sets}"
        reps.text = "${currentExercise.reps} повторений"
        weight.text = currentExercise.weight?.let { "Вес: $it кг" } ?: "Без веса"
    }

    private fun updateCurrentSetUI(
        currentSet: TextView,
        totalSets: TextView
    ) {
        val currentExercise = currentWorkout.exercises[currentExerciseIndex]
        currentSet.text = "Подход ${currentSetIndex + 1}"
        totalSets.text = "из ${currentExercise.sets}"
    }

    private fun completeCurrentSet() {
        Toast.makeText(requireContext(), "Подход ${currentSetIndex + 1} выполнен!", Toast.LENGTH_SHORT).show()
    }

    private fun startRestTimer(restTimerView: TextView, skipBtn: Button) {
        restTimerView.visibility = View.VISIBLE
        skipBtn.visibility = View.VISIBLE

        var restTime = currentWorkout.exercises[currentExerciseIndex].restTime
        restTimerView.text = "Отдых: ${restTime}с"

        restTimer = object : CountDownTimer(restTime * 1000L, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                restTime--
                restTimerView.text = "Отдых: ${restTime}с"
            }
            override fun onFinish() {
                restTimerView.visibility = View.GONE
                skipBtn.visibility = View.GONE
            }
        }
        restTimer?.start()
    }

    private fun startTimer() {
        timerRunning = true
        timerJob = CoroutineScope(Dispatchers.Main).launch {
            while (timerRunning) {
                delay(1000)
                elapsedTime++
                updateTimerUI()
            }
        }
    }

    private fun updateTimerUI() {
        view?.findViewById<TextView>(R.id.text_timer)?.let {
            val minutes = elapsedTime / 60
            val seconds = elapsedTime % 60
            it.text = String.format("%02d:%02d", minutes, seconds)
        }
    }

    private fun finishWorkout() {
        timerRunning = false
        timerJob?.cancel()
        restTimer?.cancel()

        val workoutDuration = (System.currentTimeMillis() - workoutStartTime) / 1000
        val durationInMinutes = (workoutDuration / 60).toInt()

        saveWorkoutHistory(durationInMinutes)

        showWorkoutResults(workoutDuration)
    }

    private fun saveWorkoutHistory(durationInMinutes: Int) {
        try {
            val history = WorkoutHistory(
                id = System.currentTimeMillis(),
                workoutName = currentWorkout.name,
                exercises = currentWorkout.exercises.map { exercise ->
                    ExerciseHistory(
                        name = exercise.name,
                        sets = List(exercise.sets) { setNumber ->
                            SetHistory(
                                setNumber = setNumber + 1,
                                reps = exercise.reps,
                                weight = exercise.weight,
                                completed = true
                            )
                        }
                    )
                },
                duration = durationInMinutes,
                date = System.currentTimeMillis(),
                caloriesBurned = calculateCaloriesBurned(durationInMinutes),
                notes = null
            )

            val historyJson = UserPrefsUtils.getString(requireContext(), "workout_history", "[]")
            val gson = Gson()
            val type = object : TypeToken<MutableList<WorkoutHistory>>() {}.type
            val historyList = gson.fromJson<MutableList<WorkoutHistory>>(historyJson, type) ?: mutableListOf()

            historyList.add(0, history)

            UserPrefsUtils.putString(requireContext(), "workout_history", gson.toJson(historyList))

            updateTotalWorkoutStats(durationInMinutes)

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка сохранения истории", Toast.LENGTH_SHORT).show()
        }
    }

    private fun calculateCaloriesBurned(durationMinutes: Int): Int {
        val userProfileJson = UserPrefsUtils.getString(requireContext(), "user_profile", "{}")
        val userProfile = Gson().fromJson(userProfileJson, UserProfile::class.java)
        val weight = userProfile.weight ?: 70.0

        return (weight * 0.086 * durationMinutes).toInt()
    }

    private fun updateTotalWorkoutStats(durationMinutes: Int) {
        try {
            val totalWorkouts = UserPrefsUtils.getInt(requireContext(), "total_workouts", 0)
            UserPrefsUtils.putInt(requireContext(), "total_workouts", totalWorkouts + 1)

            val totalDuration = UserPrefsUtils.getInt(requireContext(), "total_workout_duration", 0)
            UserPrefsUtils.putInt(requireContext(), "total_workout_duration", totalDuration + durationMinutes)

            UserPrefsUtils.putString(requireContext(), "last_workout_date", System.currentTimeMillis().toString())

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun showWorkoutResults(duration: Long) {
        val minutes = duration / 60
        val seconds = duration % 60

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("🎉 Тренировка завершена!")
            .setMessage(
                "Тренировка: ${currentWorkout.name}\n" +
                        "Длительность: ${minutes} мин ${seconds} сек\n" +
                        "Упражнений: ${currentWorkout.exercises.size}\n" +
                        "Всего подходов: ${currentWorkout.exercises.sumOf { it.sets }}\n" +
                        "Сожжено калорий: ~${calculateCaloriesBurned(minutes.toInt())} ккал"
            )
            .setPositiveButton("Отлично!") { _, _ ->
                requireActivity().supportFragmentManager.popBackStack()
            }
            .setCancelable(false)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        timerRunning = false
        timerJob?.cancel()
        restTimer?.cancel()
    }
}