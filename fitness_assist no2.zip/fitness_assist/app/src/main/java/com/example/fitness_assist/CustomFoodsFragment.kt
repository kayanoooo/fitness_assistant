package com.example.fitness_assist

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class CustomFoodsFragment : Fragment() {

    // Используем lateinit для отложенной инициализации
    private lateinit var customFoods: MutableList<CustomFood>
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_custom_foods, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Инициализируем список перед использованием
        customFoods = mutableListOf()

        // Инициализируем view
        listView = view.findViewById(R.id.list_foods)
        emptyText = view.findViewById(R.id.text_empty)
        val addButton = view.findViewById<Button>(R.id.button_add_food)
        val searchEditText = view.findViewById<EditText>(R.id.edit_search_food)
        val categorySpinner = view.findViewById<Spinner>(R.id.spinner_category)

        // Загружаем данные
        loadCustomFoods()

        // Настройка спиннера категорий
        val categories = listOf("Все", "Завтрак", "Обед", "Ужин", "Перекус", "Напитки", "Другое")
        val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = spinnerAdapter

        // Инициализируем адаптер
        adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            mutableListOf()
        )
        listView.adapter = adapter

        // Обновляем отображение
        updateAdapter()

        listView.setOnItemClickListener { _, _, position, _ ->
            if (position < customFoods.size) {
                showFoodDetails(customFoods[position])
            }
        }

        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (position < customFoods.size) {
                showFoodOptionsDialog(position)
            }
            true
        }

        addButton.setOnClickListener {
            showAddFoodDialog()
        }

        searchEditText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val selectedCategory = categorySpinner.selectedItem as? String ?: "Все"
                filterFoods(s.toString(), selectedCategory)
            }
        })

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                filterFoods(searchEditText.text.toString(), categories[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun loadCustomFoods() {
        try {
            val json = UserPrefsUtils.getString(requireContext(), "custom_foods", "[]")
            val type = object : TypeToken<List<CustomFood>>() {}.type
            val loadedFoods = Gson().fromJson<List<CustomFood>>(json, type) ?: emptyList()

            customFoods.clear()
            customFoods.addAll(loadedFoods)
            customFoods.sortByDescending { it.dateAdded }
        } catch (e: Exception) {
            e.printStackTrace()
            customFoods.clear()
        }
    }

    private fun saveCustomFoods() {
        try {
            val json = Gson().toJson(customFoods)
            UserPrefsUtils.putString(requireContext(), "custom_foods", json)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка сохранения", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAddFoodDialog() {
        try {
            val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_food, null)

            val categorySpinner = dialogView.findViewById<Spinner>(R.id.spinner_food_category)
            val categories = arrayOf("Завтрак", "Обед", "Ужин", "Перекус", "Напитки", "Другое")
            val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            categorySpinner.adapter = spinnerAdapter

            val dialog = androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Добавить продукт")
                .setView(dialogView)
                .setPositiveButton("Добавить") { _, _ ->
                    try {
                        val nameEdit = dialogView.findViewById<EditText>(R.id.edit_food_name)
                        val caloriesEdit = dialogView.findViewById<EditText>(R.id.edit_food_calories)

                        val name = nameEdit.text.toString().trim()
                        val caloriesText = caloriesEdit.text.toString().trim()
                        val calories = caloriesText.toIntOrNull()
                        val category = categorySpinner.selectedItem as? String ?: "Другое"

                        if (name.isEmpty()) {
                            Toast.makeText(context, "Введите название продукта", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }

                        if (calories == null || calories <= 0) {
                            Toast.makeText(context, "Введите корректное количество калорий", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }

                        val food = CustomFood(
                            id = System.currentTimeMillis().toInt(),
                            name = name,
                            calories = calories,
                            category = category,
                            dateAdded = System.currentTimeMillis()
                        )
                        customFoods.add(0, food)
                        saveCustomFoods()
                        updateAdapter()
                        Toast.makeText(context, "Продукт '$name' добавлен", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(context, "Ошибка добавления продукта", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Отмена", null)
                .create()

            dialog.show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка открытия диалога", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showFoodDetails(food: CustomFood) {
        try {
            val details = StringBuilder()
            details.append("Название: ${food.name}\n")
            details.append("Калории: ${food.calories} ккал\n")
            details.append("Категория: ${food.category}\n")

            val dateAdded = java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault())
                .format(java.util.Date(food.dateAdded))
            details.append("Добавлено: $dateAdded")

            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Информация о продукте")
                .setMessage(details.toString())
                .setPositiveButton("Добавить сегодня") { _, _ ->
                    addToToday(food)
                }
                .setNeutralButton("Редактировать") { _, _ ->
                    editFood(food)
                }
                .setNegativeButton("Закрыть", null)
                .show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка отображения деталей", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addToToday(food: CustomFood) {
        try {
            val currentCalories = UserPrefsUtils.getInt(requireContext(), "consumed_calories", 0)
            UserPrefsUtils.putInt(requireContext(), "consumed_calories", currentCalories + food.calories)

            val addedFoodsJson = UserPrefsUtils.getString(requireContext(), "added_foods", "")
            val newAddedFoods = if (addedFoodsJson.isNotEmpty()) {
                "$addedFoodsJson||${food.name} - ${food.calories} ккал"
            } else {
                "${food.name} - ${food.calories} ккал"
            }
            UserPrefsUtils.putString(requireContext(), "added_foods", newAddedFoods)

            Toast.makeText(context, "${food.name} добавлен в сегодняшний рацион", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка добавления в рацион", Toast.LENGTH_SHORT).show()
        }
    }

    private fun editFood(food: CustomFood) {
        try {
            val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_food, null)

            val nameEdit = dialogView.findViewById<EditText>(R.id.edit_food_name)
            val caloriesEdit = dialogView.findViewById<EditText>(R.id.edit_food_calories)
            val categorySpinner = dialogView.findViewById<Spinner>(R.id.spinner_food_category)

            nameEdit.setText(food.name)
            caloriesEdit.setText(food.calories.toString())

            val categories = arrayOf("Завтрак", "Обед", "Ужин", "Перекус", "Напитки", "Другое")
            val spinnerAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            categorySpinner.adapter = spinnerAdapter

            val categoryPosition = categories.indexOfFirst { it == food.category }
            if (categoryPosition != -1) {
                categorySpinner.setSelection(categoryPosition)
            }

            val dialog = androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Редактировать продукт")
                .setView(dialogView)
                .setPositiveButton("Сохранить") { _, _ ->
                    try {
                        val name = nameEdit.text.toString().trim()
                        val caloriesText = caloriesEdit.text.toString().trim()
                        val calories = caloriesText.toIntOrNull()
                        val category = categorySpinner.selectedItem as? String ?: "Другое"

                        if (name.isEmpty()) {
                            Toast.makeText(context, "Введите название продукта", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }

                        if (calories == null || calories <= 0) {
                            Toast.makeText(context, "Введите корректное количество калорий", Toast.LENGTH_SHORT).show()
                            return@setPositiveButton
                        }

                        food.name = name
                        food.calories = calories
                        food.category = category
                        saveCustomFoods()
                        updateAdapter()
                        Toast.makeText(context, "Продукт обновлен", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        e.printStackTrace()
                        Toast.makeText(context, "Ошибка обновления", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Отмена", null)
                .show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка редактирования", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showFoodOptionsDialog(position: Int) {
        try {
            if (position >= customFoods.size) return

            val food = customFoods[position]

            val options = arrayOf(
                "Добавить сегодня",
                if (food.isFavorite) "Убрать из избранного" else "В избранное",
                "Редактировать",
                "Удалить"
            )

            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle(food.name)
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> addToToday(food)
                        1 -> {
                            food.isFavorite = !food.isFavorite
                            saveCustomFoods()
                            updateAdapter()
                            val message = if (food.isFavorite) "Добавлено в избранное" else "Убрано из избранного"
                            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                        }
                        2 -> editFood(food)
                        3 -> {
                            customFoods.removeAt(position)
                            saveCustomFoods()
                            updateAdapter()
                            Toast.makeText(context, "Продукт удален", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка отображения меню", Toast.LENGTH_SHORT).show()
        }
    }

    private fun filterFoods(query: String, category: String) {
        try {
            val filtered = mutableListOf<CustomFood>()

            for (food in customFoods) {
                if (category == "Все" || food.category == category) {
                    if (query.isEmpty() || food.name.contains(query, ignoreCase = true)) {
                        filtered.add(food)
                    }
                }
            }

            if (filtered.isEmpty()) {
                listView.visibility = View.GONE
                emptyText.visibility = View.VISIBLE
                emptyText.text = if (query.isNotEmpty() || category != "Все")
                    "Ничего не найдено"
                else
                    "Список продуктов пуст\n\nНажмите '+' чтобы добавить"
            } else {
                listView.visibility = View.VISIBLE
                emptyText.visibility = View.GONE

                adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_list_item_1,
                    filtered.map { "${it.name} - ${it.calories} ккал" }
                )
                listView.adapter = adapter
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateAdapter() {
        try {
            if (customFoods.isEmpty()) {
                listView.visibility = View.GONE
                emptyText.visibility = View.VISIBLE
                emptyText.text = "Список продуктов пуст\n\nНажмите '+' чтобы добавить"
            } else {
                listView.visibility = View.VISIBLE
                emptyText.visibility = View.GONE

                adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_list_item_1,
                    customFoods.map { "${it.name} - ${it.calories} ккал" }
                )
                listView.adapter = adapter
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}