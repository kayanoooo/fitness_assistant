package com.example.fitness_assist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*

class SimpleWorkoutHistoryFragment : Fragment() {

    private lateinit var historyList: List<WorkoutHistory>
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_simple_history, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listView = view.findViewById(R.id.list_history)
        emptyText = view.findViewById(R.id.text_empty)

        loadAndDisplayHistory()
    }

    override fun onResume() {
        super.onResume()
        loadAndDisplayHistory()
    }

    private fun loadAndDisplayHistory() {
        try {
            val historyJson = UserPrefsUtils.getString(requireContext(), "workout_history", "[]")
            val gson = Gson()
            val type = object : TypeToken<List<WorkoutHistory>>() {}.type
            historyList = gson.fromJson<List<WorkoutHistory>>(historyJson, type) ?: emptyList()

            if (historyList.isEmpty()) {
                listView.visibility = View.GONE
                emptyText.visibility = View.VISIBLE
                emptyText.text = "История тренировок пуста\n\nСоздайте и выполните свою первую тренировку!"
            } else {
                listView.visibility = View.VISIBLE
                emptyText.visibility = View.GONE

                val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
                val historyItems = mutableListOf<String>()

                for (history in historyList) {
                    val dateStr = dateFormat.format(Date(history.date))
                    historyItems.add("$dateStr - ${history.workoutName}\n${history.duration} мин, ${history.exercises.size} упражнений")
                }

                val adapter = ArrayAdapter(
                    requireContext(),
                    android.R.layout.simple_list_item_2,
                    android.R.id.text1,
                    historyItems
                )
                listView.adapter = adapter

                listView.setOnItemClickListener { _, _, position, _ ->
                    showWorkoutDetails(historyList[position])
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            listView.visibility = View.GONE
            emptyText.visibility = View.VISIBLE
            emptyText.text = "Ошибка загрузки истории"
            Toast.makeText(requireContext(), "Ошибка загрузки истории", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showWorkoutDetails(history: WorkoutHistory) {
        try {
            val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
            val dateStr = dateFormat.format(Date(history.date))

            val details = StringBuilder()
            details.append("🏋️ ${history.workoutName}\n")
            details.append("📅 $dateStr\n")
            details.append("⏱ ${history.duration} минут\n")

            if (history.caloriesBurned != null) {
                details.append("🔥 ${history.caloriesBurned} ккал\n")
            }

            details.append("\n📋 Упражнения (${history.exercises.size}):\n")

            for ((index, exercise) in history.exercises.withIndex()) {
                details.append("\n${index + 1}. ${exercise.name}\n")
                for (set in exercise.sets) {
                    val weightStr = if (set.weight != null) " с весом ${set.weight} кг" else ""
                    details.append("   ● Подход ${set.setNumber}: ${set.reps} повторений$weightStr\n")
                }
            }

            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Детали тренировки")
                .setMessage(details.toString())
                .setPositiveButton("Закрыть", null)
                .show()
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(requireContext(), "Ошибка отображения деталей", Toast.LENGTH_SHORT).show()
        }
    }
}