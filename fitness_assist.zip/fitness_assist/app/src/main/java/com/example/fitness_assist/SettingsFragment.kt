package com.example.fitness_assist

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    private lateinit var prefsName: String
    private lateinit var waterGoalEditText: EditText
    private lateinit var currentGoalTextView: TextView

    override fun onAttach(context: Context) {
        super.onAttach(context)
        prefsName = "${requireContext().packageName}_prefs"
    }


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        // Инициализация элементов
        waterGoalEditText = view.findViewById(R.id.et_water_goal)
        currentGoalTextView = view.findViewById(R.id.tv_current_goal)
        val saveBtn = view.findViewById<Button>(R.id.btn_save_settings)
        val resetAllBtn = view.findViewById<Button>(R.id.btn_reset_all)

        // Загружаем текущие настройки
        loadCurrentSettings()

        // Сохранение настроек
        saveBtn.setOnClickListener {
            saveSettings()
        }

        // Сброс всех данных
        resetAllBtn.setOnClickListener {
            resetAllData()
        }

        return view
    }

    private fun loadCurrentSettings() {
        val prefs = requireContext().getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val currentGoal = prefs.getInt("water_goal", 8) // По умолчанию 8 стаканов
        currentGoalTextView.text = "Текущая цель: $currentGoal стаканов"
        waterGoalEditText.setText(currentGoal.toString())
    }

    private fun saveSettings() {
        val goalText = waterGoalEditText.text.toString()

        if (goalText.isNotEmpty()) {
            val goal = goalText.toIntOrNull()

            if (goal != null && goal in 1..20) { // Ограничение от 1 до 20 стаканов
                val prefs = requireContext().getSharedPreferences(prefsName, Context.MODE_PRIVATE)
                prefs.edit().putInt("water_goal", goal).apply()

                currentGoalTextView.text = "Текущая цель: $goal стаканов"
                Toast.makeText(context, "Настройки сохранены", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Введите число от 1 до 20", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Введите цель", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetAllData() {
        val prefs = requireContext().getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.clear() // Удаляем все данные
        editor.apply()

        // Устанавливаем значения по умолчанию
        editor.putInt("water_goal", 8)
        editor.putInt("calorie_goal", 2000)
        editor.apply()

        loadCurrentSettings()
        Toast.makeText(context, "Все данные сброшены", Toast.LENGTH_SHORT).show()
    }


}