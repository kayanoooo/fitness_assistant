package com.example.fitness_assist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class CustomWorkoutFragment : Fragment() {

    private lateinit var workoutList: MutableList<CustomWorkout>
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_custom_workout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadWorkouts()

        val listView = view.findViewById<ListView>(R.id.lv_workouts)
        val addButton = view.findViewById<Button>(R.id.btn_add_workout)
        val searchEditText = view.findViewById<EditText>(R.id.et_search_workout)

        adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            workoutList.map { it.name }
        )
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            val workout = workoutList[position]
            openWorkoutEditor(workout)
        }

        listView.setOnItemLongClickListener { _, _, position, _ ->
            showWorkoutMenu(position)
            true
        }

        addButton.setOnClickListener {
            createNewWorkout()
        }

        searchEditText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                filterWorkouts(s.toString())
            }
        })
    }

    private fun loadWorkouts() {
        val json = UserPrefsUtils.getString(requireContext(), "custom_workouts", "[]")
        val type = object : TypeToken<MutableList<CustomWorkout>>() {}.type
        workoutList = Gson().fromJson(json, type) ?: mutableListOf()
    }

    private fun saveWorkouts() {
        val json = Gson().toJson(workoutList)
        UserPrefsUtils.putString(requireContext(), "custom_workouts", json)
    }

    private fun createNewWorkout() {
        val workout = CustomWorkout(
            id = workoutList.size + 1,
            name = "Новая тренировка ${workoutList.size + 1}",
            description = "Описание тренировки"
        )
        workoutList.add(workout)
        saveWorkouts()
        adapter.clear()
        adapter.addAll(workoutList.map { it.name })
        adapter.notifyDataSetChanged()
        openWorkoutEditor(workout)
    }

    private fun openWorkoutEditor(workout: CustomWorkout) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_edit_workout, null)

        val dialog = androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Редактирование тренировки")
            .setView(dialogView)
            .setPositiveButton("Сохранить") { _, _ ->
                val nameEditText = dialogView.findViewById<EditText>(R.id.et_workout_name)
                val descEditText = dialogView.findViewById<EditText>(R.id.et_workout_desc)

                workout.name = nameEditText.text.toString()
                workout.description = descEditText.text.toString()
                saveWorkoutChanges(workout)
            }
            .setNegativeButton("Отмена", null)
            .create()

        val nameEditText = dialogView.findViewById<EditText>(R.id.et_workout_name)
        val descEditText = dialogView.findViewById<EditText>(R.id.et_workout_desc)
        val exercisesListView = dialogView.findViewById<ListView>(R.id.lv_exercises)
        val addExerciseBtn = dialogView.findViewById<Button>(R.id.btn_add_exercise)

        nameEditText.setText(workout.name)
        descEditText.setText(workout.description)

        val exercisesAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            workout.exercises.map { it.name }
        )
        exercisesListView?.adapter = exercisesAdapter

        addExerciseBtn?.setOnClickListener {
            addExerciseToWorkout(workout, exercisesAdapter)
        }

        dialog.show()
    }

    private fun addExerciseToWorkout(workout: CustomWorkout, exercisesAdapter: ArrayAdapter<String>) {
        val dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_exercise, null)

        val dialog = androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle("Добавить упражнение")
            .setView(dialogView)
            .setPositiveButton("Добавить") { _, _ ->
                val name = dialogView.findViewById<EditText>(R.id.et_exercise_name)?.text.toString()
                val sets = dialogView.findViewById<EditText>(R.id.et_sets)?.text.toString().toIntOrNull() ?: 3
                val reps = dialogView.findViewById<EditText>(R.id.et_reps)?.text.toString().toIntOrNull() ?: 10
                val weight = dialogView.findViewById<EditText>(R.id.et_weight)?.text.toString().toDoubleOrNull()

                if (name.isNotEmpty()) {
                    val exercise = Exercise(
                        id = workout.exercises.size + 1,
                        name = name,
                        description = "",
                        sets = sets,
                        reps = reps,
                        weight = weight
                    )
                    workout.exercises.add(exercise)
                    exercisesAdapter.clear()
                    exercisesAdapter.addAll(workout.exercises.map { it.name })
                    exercisesAdapter.notifyDataSetChanged()
                }
            }
            .setNegativeButton("Отмена", null)
            .create()

        dialog.show()
    }

    private fun saveWorkoutChanges(workout: CustomWorkout) {
        workout.lastModified = System.currentTimeMillis()
        saveWorkouts()
        adapter.clear()
        adapter.addAll(workoutList.map { it.name })
        adapter.notifyDataSetChanged()
    }

    private fun showWorkoutMenu(position: Int) {
        val workout = workoutList[position]

        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(workout.name)
            .setItems(arrayOf("Редактировать", "Удалить", "Начать тренировку")) { _, which ->
                when (which) {
                    0 -> openWorkoutEditor(workout)
                    1 -> {
                        workoutList.removeAt(position)
                        saveWorkouts()
                        adapter.clear()
                        adapter.addAll(workoutList.map { it.name })
                        adapter.notifyDataSetChanged()
                    }
                    2 -> startWorkout(workout)
                }
            }
            .show()
    }


    private fun startWorkout(workout: CustomWorkout) {
        val executionFragment = WorkoutExecutionFragment.newInstance(workout)

        requireActivity().supportFragmentManager.beginTransaction()
            .replace(R.id.nav_host_fragment, executionFragment)
            .addToBackStack(null)
            .commit()
    }

    private fun filterWorkouts(query: String) {
        if (query.isEmpty()) {
            adapter.clear()
            adapter.addAll(workoutList.map { it.name })
        } else {
            val filtered = workoutList.filter {
                it.name.contains(query, ignoreCase = true) ||
                        it.description.contains(query, ignoreCase = true)
            }
            adapter.clear()
            adapter.addAll(filtered.map { it.name })
        }
        adapter.notifyDataSetChanged()
    }
}