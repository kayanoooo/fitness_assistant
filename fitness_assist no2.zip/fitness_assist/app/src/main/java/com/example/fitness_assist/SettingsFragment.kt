package com.example.fitness_assist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment

class SettingsFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_settings, container, false)

        val waterGoalEditText = view.findViewById<EditText>(R.id.et_water_goal)
        val currentGoalTextView = view.findViewById<TextView>(R.id.tv_current_goal)
        val currentUserTextView = view.findViewById<TextView>(R.id.tv_current_user)
        val saveBtn = view.findViewById<Button>(R.id.btn_save_settings)
        val resetAllBtn = view.findViewById<Button>(R.id.btn_reset_all)
        val logoutBtn = view.findViewById<Button>(R.id.btn_logout)

        loadCurrentSettings(currentGoalTextView, currentUserTextView, waterGoalEditText)

        saveBtn.setOnClickListener {
            saveSettings(waterGoalEditText, currentGoalTextView)
        }

        resetAllBtn.setOnClickListener {
            resetAllData(currentGoalTextView, currentUserTextView, waterGoalEditText)
        }

        logoutBtn.setOnClickListener {
            logoutUser()
        }

        return view
    }

    private fun loadCurrentSettings(goalTextView: TextView, userTextView: TextView, goalEditText: EditText) {
        val currentGoal = UserPrefsUtils.getInt(requireContext(), "water_goal", 8)
        goalTextView.text = "Текущая цель: $currentGoal стаканов"
        goalEditText.setText(currentGoal.toString())

        val userEmail = UserPrefsUtils.getCurrentUserEmail(requireContext())
        val isGuest = UserPrefsUtils.isGuest(requireContext())

        if (isGuest) {
            userTextView.text = "Пользователь: Гость"
        } else {
            userTextView.text = "Пользователь: $userEmail"
        }
    }

    private fun saveSettings(goalEditText: EditText, goalTextView: TextView) {
        val goalText = goalEditText.text.toString()

        if (goalText.isNotEmpty()) {
            val goal = goalText.toIntOrNull()

            if (goal != null && goal in 1..20) {
                UserPrefsUtils.putInt(requireContext(), "water_goal", goal)
                goalTextView.text = "Текущая цель: $goal стаканов"
                Toast.makeText(context, "Настройки сохранены", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Введите число от 1 до 20", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Введите цель", Toast.LENGTH_SHORT).show()
        }
    }

    private fun resetAllData(goalTextView: TextView, userTextView: TextView, goalEditText: EditText) {
        UserPrefsUtils.resetCurrentUserData(requireContext())

        UserPrefsUtils.putInt(requireContext(), "water_goal", 8)
        UserPrefsUtils.putInt(requireContext(), "calorie_goal", 2000)

        loadCurrentSettings(goalTextView, userTextView, goalEditText)
        Toast.makeText(context, "Данные текущего пользователя сброшены", Toast.LENGTH_SHORT).show()
    }

    private fun logoutUser() {
        UserPrefsUtils.logout(requireContext())

        Toast.makeText(context, "Вы вышли из системы", Toast.LENGTH_SHORT).show()

        (requireActivity() as MainActivity).restartApp()
    }
}