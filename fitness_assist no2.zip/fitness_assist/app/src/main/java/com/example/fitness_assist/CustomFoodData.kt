package com.example.fitness_assist

import java.io.Serializable

data class CustomFood(
    val id: Int,
    var name: String,
    var calories: Int,
    var protein: Double? = null,
    var carbs: Double? = null,
    var fat: Double? = null,
    var category: String = "Другое",
    var dateAdded: Long = System.currentTimeMillis(),
    var isFavorite: Boolean = false
) : Serializable {

    init {
        if (calories < 0) calories = 0
    }
}