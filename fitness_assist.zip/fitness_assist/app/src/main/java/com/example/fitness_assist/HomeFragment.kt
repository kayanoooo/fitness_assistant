package com.example.fitness_assist

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        view.findViewById<View>(R.id.btn_workout).setOnClickListener {
            findNavController().navigate(R.id.action_home_to_workout)
        }

        view.findViewById<View>(R.id.btn_water).setOnClickListener {
            findNavController().navigate(R.id.action_home_to_water)
        }

        view.findViewById<View>(R.id.btn_nutrition).setOnClickListener {
            findNavController().navigate(R.id.action_home_to_nutrition)
        }

        view.findViewById<View>(R.id.btn_settings).setOnClickListener {
            findNavController().navigate(R.id.action_home_to_settings)
        }

        return view
    }
}