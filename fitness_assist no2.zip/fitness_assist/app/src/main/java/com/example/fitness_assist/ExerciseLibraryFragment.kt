package com.example.fitness_assist

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class ExerciseLibraryFragment : Fragment() {

    private val exerciseLibrary = listOf(
        ExerciseLibraryItem(
            1, "Приседания", "Ноги",
            "Базовое упражнение для ног и ягодиц",
            "1. Поставьте ноги на ширине плеч\n2. Держите спину прямой\n3. Опускайтесь до параллели бедер с полом\n4. Поднимайтесь в исходное положение",
            listOf("Квадрицепсы", "Бицепсы бедер", "Ягодицы"),
            "Начальный", "Без оборудования"
        ),
        ExerciseLibraryItem(
            2, "Отжимания", "Грудь",
            "Упражнение для грудных мышц и трицепсов",
            "1. Примите упор лежа\n2. Ладони на ширине плеч\n3. Опускайтесь грудью к полу\n4. Отжимайтесь в исходное положение",
            listOf("Грудные", "Трицепсы", "Плечи"),
            "Начальный", "Без оборудования"
        ),
        ExerciseLibraryItem(
            3, "Подтягивания", "Спина",
            "Упражнение для развития широчайших мышц спины",
            "1. Возьмитесь за перекладину прямым хватом\n2. Подтягивайтесь до подбородка\n3. Медленно опускайтесь",
            listOf("Широчайшие", "Бицепсы", "Предплечья"),
            "Средний", "Турник"
        ),
        ExerciseLibraryItem(
            4, "Жим лежа", "Грудь",
            "Базовое упражнение для развития грудных мышц",
            "1. Лягте на скамью\n2. Возьмите штангу прямым хватом\n3. Опустите штангу к груди\n4. Выжмите вверх",
            listOf("Грудные", "Трицепсы", "Плечи"),
            "Средний", "Штанга, скамья"
        ),
        ExerciseLibraryItem(
            5, "Становая тяга", "Спина",
            "Базовое упражнение для всего тела",
            "1. Возьмите штангу прямым хватом\n2. Держите спину прямой\n3. Поднимайте штангу вдоль ног\n4. Вернитесь в исходное положение",
            listOf("Широчайшие", "Ноги", "Ягодицы", "Разгибатели спина"),
            "Продвинутый", "Штанга"
        ),
        ExerciseLibraryItem(
            6, "Планка", "Пресс",
            "Упражнение для укрепления кора",
            "1. Примите упор на предплечьях\n2. Держите тело прямо\n3. Напрягите пресс и ягодицы\n4. Удерживайте положение",
            listOf("Пресс", "Разгибатели спины"),
            "Начальный", "Без оборудования"
        ),
        ExerciseLibraryItem(
            7, "Выпады", "Ноги",
            "Упражнение для ног и ягодиц",
            "1. Сделайте шаг вперед\n2. Опускайтесь до прямого угла в коленях\n3. Вернитесь в исходное положение\n4. Повторите на другую ногу",
            listOf("Квадрицепсы", "Ягодицы"),
            "Начальный", "Без оборудования"
        ),
        ExerciseLibraryItem(
            8, "Бицепс с гантелями", "Руки",
            "Изолирующее упражнение для бицепсов",
            "1. Возьмите гантели в обе руки\n2. Сгибайте руки в локтях\n3. Поднимайте гантели к плечам\n4. Медленно опускайте",
            listOf("Бицепсы"),
            "Начальный", "Гантели"
        ),
        ExerciseLibraryItem(
            9, "Жим гантелей сидя", "Плечи",
            "Упражнение для развития плеч",
            "1. Сядьте на скамью\n2. Возьмите гантели на уровень плеч\n3. Выжимайте гантели вверх\n4. Медленно опускайте",
            listOf("Дельтовидные"),
            "Средний", "Гантели, скамья"
        ),
        ExerciseLibraryItem(
            10, "Гиперэкстензия", "Спина",
            "Упражнение для укрепления низа спины",
            "1. Закрепитесь в тренажере\n2. Наклонитесь вперед\n3. Поднимайте корпус до прямой линии с ногами",
            listOf("Разгибатели спины"),
            "Начальный", "Тренажер"
        )
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_exercise_library, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val listView = view.findViewById<ListView>(R.id.lv_exercise_library)
        val spinner = view.findViewById<Spinner>(R.id.sp_category_filter)
        val searchEditText = view.findViewById<EditText>(R.id.et_search_exercise)

        val categories = listOf("Все") + exerciseLibrary.map { it.category }.distinct()
        val categoryAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, categories)
        spinner.adapter = categoryAdapter

        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            exerciseLibrary.map { it.name }
        )
        listView.adapter = adapter

        listView.setOnItemClickListener { _, _, position, _ ->
            showExerciseDetails(exerciseLibrary[position])
        }

        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                filterExercises(searchEditText.text.toString(), categories[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        searchEditText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                val selectedCategory = spinner.selectedItem as? String ?: "Все"
                filterExercises(s.toString(), selectedCategory)
            }
        })
    }

    private fun showExerciseDetails(exercise: ExerciseLibraryItem) {
        androidx.appcompat.app.AlertDialog.Builder(requireContext())
            .setTitle(exercise.name)
            .setMessage(
                "Категория: ${exercise.category}\n\n" +
                        "Описание: ${exercise.description}\n\n" +
                        "Техника выполнения:\n${exercise.technique}\n\n" +
                        "Рабочие мышцы: ${exercise.muscles.joinToString(", ")}\n\n" +
                        "Сложность: ${exercise.difficulty}\n" +
                        "Оборудование: ${exercise.equipment}"
            )
            .setPositiveButton("Добавить в тренировку") { _, _ ->
                addToCustomWorkout(exercise)
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun addToCustomWorkout(exercise: ExerciseLibraryItem) {
        Toast.makeText(requireContext(), "${exercise.name} добавлено в тренировку", Toast.LENGTH_SHORT).show()
    }

    private fun filterExercises(query: String, category: String) {
        var filtered = exerciseLibrary

        if (category != "Все") {
            filtered = filtered.filter { it.category == category }
        }

        if (query.isNotEmpty()) {
            filtered = filtered.filter {
                it.name.contains(query, ignoreCase = true) ||
                        it.description.contains(query, ignoreCase = true) ||
                        it.muscles.any { muscle -> muscle.contains(query, ignoreCase = true) }
            }
        }

        val listView = view?.findViewById<ListView>(R.id.lv_exercise_library)
        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_list_item_1,
            filtered.map { it.name }
        )
        listView?.adapter = adapter
    }
}

data class ExerciseLibraryItem(
    val id: Int,
    val name: String,
    val category: String,
    val description: String,
    val technique: String,
    val muscles: List<String>,
    val difficulty: String,
    val equipment: String
)