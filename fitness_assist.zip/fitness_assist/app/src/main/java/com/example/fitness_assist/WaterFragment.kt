package com.example.fitness_assist

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView

class WaterFragment : Fragment() {
    private var waterCount = 0
    private var dailyGoal = 8
    private lateinit var prefsName: String

    override fun onAttach(context: Context) {
        super.onAttach(context)
        prefsName = "${requireContext().packageName}_prefs"
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_water, container, false)

        // Загружаем сохранённые значения
        val prefs = requireContext().getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        waterCount = prefs.getInt("water_count", 0)
        dailyGoal = prefs.getInt("water_goal", 8) // Загружаем настраиваемую цель

        val waterTextView = view.findViewById<TextView>(R.id.tv_water_count)
        val progressBar = view.findViewById<ProgressBar>(R.id.progress_bar)
        val addBtn = view.findViewById<Button>(R.id.btn_add_water)
        val resetBtn = view.findViewById<Button>(R.id.btn_reset_water)

        updateUI(waterTextView, progressBar)

        addBtn.setOnClickListener {
            if (waterCount < dailyGoal) {
                waterCount++
                saveWaterCount()
                updateUI(waterTextView, progressBar)

                // Поздравление при достижении цели
                if (waterCount == dailyGoal) {
                    android.widget.Toast.makeText(
                        context,
                        "🎉 Поздравляем! Вы достигли дневной нормы!",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            } else {
                android.widget.Toast.makeText(
                    context,
                    "Вы уже достигли дневной нормы!",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }

        resetBtn.setOnClickListener {
            waterCount = 0
            saveWaterCount()
            updateUI(waterTextView, progressBar)
            android.widget.Toast.makeText(
                context,
                "Счётчик сброшен",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }

        return view
    }

    private fun updateUI(textView: TextView, progressBar: ProgressBar) {
        textView.text = "$waterCount/$dailyGoal стаканов"
        val progress = if (dailyGoal > 0) {
            (waterCount.toFloat() / dailyGoal * 100).toInt()
        } else {
            0
        }
        progressBar.progress = progress

        // Меняем цвет прогресс-бара в зависимости от заполненности
        if (progress >= 100) {
            progressBar.progressTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#4CAF50") // Зелёный
            )
        } else if (progress >= 50) {
            progressBar.progressTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#2196F3") // Синий
            )
        } else {
            progressBar.progressTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#FF9800") // Оранжевый
            )
        }
    }

    private fun saveWaterCount() {
        val prefs = requireContext().getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        prefs.edit().putInt("water_count", waterCount).apply()
    }
}