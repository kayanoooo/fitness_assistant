package com.example.fitness_assist

import java.io.Serializable

data class WorkoutHistory(
    val id: Long,
    val workoutName: String,
    val exercises: List<ExerciseHistory>,
    val duration: Int,
    val date: Long,
    val caloriesBurned: Int? = null,
    val notes: String? = null
) : Serializable

data class ExerciseHistory(
    val name: String,
    val sets: List<SetHistory>
) : Serializable

data class SetHistory(
    val setNumber: Int,
    val reps: Int,
    val weight: Double?,
    val completed: Boolean
) : Serializable