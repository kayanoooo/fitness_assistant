package com.example.fitness_assist

data class Exercise(
    val id: Int,
    var name: String,
    var description: String,
    var sets: Int = 3,
    var reps: Int = 10,
    var weight: Double? = null,
    var restTime: Int = 60 // секунды
)

data class CustomWorkout(
    val id: Int,
    var name: String,
    var description: String,
    var exercises: MutableList<Exercise> = mutableListOf(),
    var dateCreated: Long = System.currentTimeMillis(),
    var lastModified: Long = System.currentTimeMillis()
)


data class WorkoutExecution(
    val workoutId: Int,
    val workoutName: String,
    val startTime: Long,
    var endTime: Long? = null,
    val exercises: List<ExerciseExecution> = mutableListOf()
)

data class ExerciseExecution(
    val exerciseName: String,
    val sets: List<SetExecution> = mutableListOf()
)

data class SetExecution(
    val setNumber: Int,
    val targetReps: Int,
    val completedReps: Int? = null,
    val targetWeight: Double? = null,
    val actualWeight: Double? = null,
    val completed: Boolean = false
)