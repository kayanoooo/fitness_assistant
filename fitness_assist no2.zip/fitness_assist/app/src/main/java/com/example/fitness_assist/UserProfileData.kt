package com.example.fitness_assist

import java.io.Serializable

data class UserProfile(
    var name: String = "Гость",
    var age: Int? = null,
    var height: Double? = null,
    var weight: Double? = null,
    var gender: String = "unknown",
    var fitnessGoal: String = "maintenance",
    var activityLevel: String = "moderate",
    var dailyCalorieGoal: Int = 2000,
    var profileImageUri: String = "",
    var createdAt: Long = System.currentTimeMillis(),
    var lastUpdated: Long = System.currentTimeMillis()
) : Serializable {

    fun calculateBMR(): Double? {
        if (weight == null || height == null || age == null) return null

        return when (gender) {
            "male" -> 88.362 + (13.397 * weight!!) + (4.799 * height!!) - (5.677 * age!!)
            "female" -> 447.593 + (9.247 * weight!!) + (3.098 * height!!) - (4.330 * age!!)
            else -> null
        }
    }

    fun calculateDailyCalories(): Int? {
        val bmr = calculateBMR() ?: return null

        val activityMultiplier = when (activityLevel) {
            "sedentary" -> 1.2
            "light" -> 1.375
            "moderate" -> 1.55
            "active" -> 1.725
            "very_active" -> 1.9
            else -> 1.55
        }

        val baseCalories = (bmr * activityMultiplier).toInt()

        return when (fitnessGoal) {
            "weight_loss" -> (baseCalories * 0.85).toInt() // дефицит 15%
            "muscle_gain" -> (baseCalories * 1.15).toInt() // профицит 15%
            else -> baseCalories
        }
    }

    fun calculateBMI(): Double? {
        if (weight == null || height == null || height == 0.0) return null
        val heightMeters = height!! / 100
        return weight!! / (heightMeters * heightMeters)
    }

    fun getBMICategory(): String {
        val bmi = calculateBMI() ?: return "Недостаточно данных"

        return when {
            bmi < 16 -> "Выраженный дефицит"
            bmi < 18.5 -> "Недостаточный вес"
            bmi < 25 -> "Нормальный вес"
            bmi < 30 -> "Избыточный вес"
            bmi < 35 -> "Ожирение 1 степени"
            bmi < 40 -> "Ожирение 2 степени"
            else -> "Ожирение 3 степени"
        }
    }
}